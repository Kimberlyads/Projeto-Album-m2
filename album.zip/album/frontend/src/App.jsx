import { useEffect, useState } from 'react';
import './App.css';

const API = 'http://127.0.0.1:8000/api/album/';

function App() {
  const [album, setalbum] = useState([]);
  const [titulo, settitulo] = useState("");
  const [artista, setartista] = useState("");
  const [ano, setano] = useState("");
  const [avaliacao, setavaliacao] = useState("");
  function carregaralbum () {
    fetch(API)
      .then((res) => res.json())
      .then((dados) => setalbum(dados));
  }
  useEffect(() => {
    carregaralbum();
  }, [] );
  function cadastrar (evento) {
    evento.preventDefault();

    fetch (API, {
      method:'POST',
      headers: { 'Content-Type':'application/json'},
      body: JSON.stringify({
        titulo: titulo,
        artista: artista,
        ano: Number(ano),
        avaliacao: Number(avaliacao),
      }),
    })
    .then (() => {
      settitulo('');
      setartista('');
      setano('');
      setavaliacao('');
      carregaralbum();
  });
  }
  return (
    <div className='pagina'>
      <h1>Cadastro de album</h1>
      <form onSubmit={cadastrar}>
        <input
          placeholder='Titulo'
          value={titulo}
          onChange={(e) => settitulo (e.target.value)}
          required
        />
        <input
          placeholder='Nome do Artista'
          value={artista}
          onChange={(e) => setartista (e.target.value)}
          required
        />
        <input
          type='number'
          placeholder="Ano de lançamento"
          min="1900"
          max="2100"
          value={ano}
          onChange={(e) =>
          setano(e.target.value)} required />
        <input
          type='number'
          placeholder="Avaliação"
          step="0.1"
          min="0"
          max="5"
          value={avaliacao} onChange={(e) => setavaliacao(e.target.value)} required />
      <button type='submit'>cadastrar</button>
      </form>
      <h2>Albuns cadastrados</h2>
      <ul>
        {album.map((album) => (
          <li key={album.id}>
            {album.titulo} · artista {album.artista} · ano {album.ano} · avaliacao {album.avaliacao}
          </li>
        ))}
      </ul>
    </div>
  );
}


export default App;