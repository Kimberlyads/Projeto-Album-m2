
import json

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from .models import album

@csrf_exempt
def api_album (request):
    if request.method =="POST":
        dados = json.loads(request.body)
        novo_album = album.objects.create(
            titulo=dados['titulo'],
            artista=dados['artista'],
            ano=dados['ano'],
            avaliacao=dados['avaliacao'],
        )
        return JsonResponse({'id':novo_album.id} , status=201)
    albuns = list (album.objects.values())
    return JsonResponse(albuns, safe=False)